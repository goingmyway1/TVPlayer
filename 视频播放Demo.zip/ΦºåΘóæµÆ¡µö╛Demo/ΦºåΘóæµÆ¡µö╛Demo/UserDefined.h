//
//  UserDefined.h
//  视频播放Demo
//
//  Created by Sheffi on 16/10/8.
//  Copyright © 2016年 青岛晨之晖信息服务有限公司. All rights reserved.
//

#define SCREEN_H ([[UIScreen mainScreen] bounds].size.height)
#define SCREEN_W ([[UIScreen mainScreen] bounds].size.width)

//每个电视台的url
#define TVURL_CCTV1 @"http://ivi.bupt.edu.cn/hls/cctv1hd.m3u8"
#define TVURL_CCTV3 @"http://ivi.bupt.edu.cn/hls/cctv3hd.m3u8"
#define TVURL_CCTV5 @"http://ivi.bupt.edu.cn/hls/cctv5hd.m3u8"
#define TVURL_CCTV5_1 @"http://ivi.bupt.edu.cn/hls/cctv5phd.m3u8"
#define TVURL_CCTV6 @"http://ivi.bupt.edu.cn/hls/cctv6hd.m3u8"
#define TVURL_CCTV8 @"http://ivi.bupt.edu.cn/hls/cctv8hd.m3u8"
#define TVURL_CHC @"http://ivi.bupt.edu.cn/hls/chchd.m3u8"
#define TVURL_BeiJingSport @"http://ivi.bupt.edu.cn/hls/btv6hd.m3u8"
#define TVURL_HuNan @"http://ivi.bupt.edu.cn/hls/hunanhd.m3u8"
#define TVURL_ZheJiang @"http://ivi.bupt.edu.cn/hls/zjhd.m3u8"
#define TVURL_GuangDong @"http://ivi.bupt.edu.cn/hls/gdhd.m3u8"
#define TVURL_TianJin @"http://ivi.bupt.edu.cn/hls/tjhd.m3u8"
#define TVURL_Motel @"http://wow01.105.net/live/virgin1/playlist.m3u8"
