//
//  ViewController.m
//  视频播放Demo
//
//  Created by Sheffi on 16/10/8.
//  Copyright © 2016年 青岛晨之晖信息服务有限公司. All rights reserved.
//

#import "ViewController.h"
#import "UserDefined.h"
#import "PlayViewController.h"
@interface ViewController ()<UITableViewDataSource,UITableViewDelegate>
@property (strong, nonatomic) IBOutlet UITableView *tableView;
@property (strong, nonatomic) NSArray *dataArr;
@property (strong, nonatomic) NSArray *tvUrlArr;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _dataArr = @[@"CCTV1",@"CCTV3",@"CCTV5",@"CCTV5+",@"CCTV6",@"CCTV8",@"CHCTV",@"北京体育",@"湖南卫视",@"浙江卫视",@"广东卫视",@"天津卫视",@"MotelTV"];
    _tvUrlArr = @[TVURL_CCTV1,TVURL_CCTV3,TVURL_CCTV5,TVURL_CCTV5_1,TVURL_CCTV6,TVURL_CCTV8,TVURL_CHC,TVURL_BeiJingSport,TVURL_HuNan,TVURL_ZheJiang,TVURL_GuangDong,TVURL_TianJin,TVURL_Motel];
    _tableView.frame = CGRectMake(0, 0, SCREEN_W, SCREEN_H);
    _tableView.delegate = self;
    _tableView.dataSource = self;
}
#pragma mark - tableView delegate & tableView datasource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section;
{
    return _dataArr.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    cell.textLabel.text = [_dataArr objectAtIndex:indexPath.row];
    cell.layer.borderWidth = 0.8;
    cell.layer.borderColor = [UIColor lightGrayColor].CGColor;
    return cell;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    CGFloat height = 40;
    return height;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
    PlayViewController *vc = [storyboard instantiateViewControllerWithIdentifier:@"PlayViewController"];
    NSString *tvUrl = [_tvUrlArr objectAtIndex:indexPath.row];
    [vc setValue:tvUrl forKey:@"playUrl"];
    vc.title = [_dataArr objectAtIndex:indexPath.row];
    [self.navigationController pushViewController:vc animated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
