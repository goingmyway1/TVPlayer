//
//  PlayViewController.m
//  视频播放Demo
//
//  Created by Sheffi on 16/10/8.
//  Copyright © 2016年 青岛晨之晖信息服务有限公司. All rights reserved.
//

#import "PlayViewController.h"
#import "VMediaPlayer.h"
@interface PlayViewController ()<VMediaPlayerDelegate>
@property (nonatomic, strong)VMediaPlayer *vPlay;
@end

@implementation PlayViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    NSLog(@"%@",_playUrl);
   
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    _vPlay = [VMediaPlayer sharedInstance];
    [_vPlay setupPlayerWithCarrierView:self.view withDelegate:self];
    
    NSURL *vUrl = [NSURL URLWithString:_playUrl];
    [_vPlay setDataSource:vUrl header:nil];
    [_vPlay prepareAsync];

}
-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    
}
-(void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
    [_vPlay reset];
    [_vPlay unSetupPlayer];
    
}
// 当'播放器准备完成'时, 该协议方法被调用, 我们可以在此调用 [player start]
// 来开始音视频的播放.
- (void)mediaPlayer:(VMediaPlayer *)player didPrepared:(id)arg
{
    [player start];
}
// 当'该音视频播放完毕'时, 该协议方法被调用, 我们可以在此作一些播放器善后
// 操作, 如: 重置播放器, 准备播放下一个音视频等
- (void)mediaPlayer:(VMediaPlayer *)player playbackComplete:(id)arg
{
    [player reset];
}
// 如果播放由于某某原因发生了错误, 导致无法正常播放, 该协议方法被调用, 参
// 数 arg 包含了错误原因.
- (void)mediaPlayer:(VMediaPlayer *)player error:(id)arg
{
    NSLog(@"NAL 1RRE &&&& VMediaPlayer Error: %@", arg);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
