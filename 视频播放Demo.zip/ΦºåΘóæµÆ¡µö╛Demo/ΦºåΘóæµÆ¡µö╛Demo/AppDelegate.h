//
//  AppDelegate.h
//  视频播放Demo
//
//  Created by Sheffi on 16/10/8.
//  Copyright © 2016年 青岛晨之晖信息服务有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

